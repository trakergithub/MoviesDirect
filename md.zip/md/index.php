<!doctype html>
<title>Movies Direct</title>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="files/imagenes/logo.png" rel="icon">
<link rel="stylesheet" href="files/css/stylefb.css">

</head>

<body>
  <header class="superponer">
    <span width="90%" class="single-line"><img height='100%' src='files/imagenes/pcmd.png' /> La manera mas sencilla de ver tus películas favoritas </span>
  </header>

  <?php
     include 'files/controllers/content.php';
  ?>
    
    <div class="fondo fondobg"></div>


  <!--footer class="superponer">

  </footer-->
</body>